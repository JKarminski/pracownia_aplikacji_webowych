import './App.scss'
import Navbar from "./components/Navbar/Navbar.tsx";

function App() {
  return (
    <>
      <Navbar />
    </>
  )
}

export default App
